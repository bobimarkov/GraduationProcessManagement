<?php

namespace Mpdf;

class MpdfException extends \ErrorException
{

}
