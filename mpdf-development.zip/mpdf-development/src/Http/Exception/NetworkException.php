<?php

namespace Mpdf\Http\Exception;

class NetworkException extends \Mpdf\MpdfException
{

}
